/* 1. Write a menu driven program to implement a doubly linked list with the following operations
a. Insert an element at any position (front, end or intermediate)
b. Delete an element from any position (front, end or intermediate)
c. Display the list
*/

#include<stdio.h>
#include<stdlib.h>

struct node   
{  
    struct node *prev;
    int data;  
    struct node *next;
};

struct node *create(int);
struct node *insert_front(struct node *, int);
struct node *insert_end(struct node *, int);
struct node *insert_mid(struct node *, int, int);
struct node *insert_after(struct node *, int, int);
struct node *insert_before(struct node *, int, int);
struct node *delete_front(struct node *);
struct node *delete_end(struct node *);
struct node *delete_mid(struct node *, int);
struct node *delete_after(struct node *, int);
struct node *delete_before(struct node *, int);
void display(struct node *);
int count_nodes(struct node *);

struct node *create(int value)
{
	struct node *ptr;
	ptr = (struct node *)malloc(sizeof(struct node));
	ptr->prev = NULL;
	ptr->data = value;
	ptr->next = NULL;
	return ptr;
}

struct node *insert_front(struct node *start, int value)
{
	struct node *ptr;
	if(start == NULL)
		start = create(value);
	else
	{
		ptr = (struct node *)malloc(sizeof(struct node));
		ptr->prev = NULL;
		ptr->data = value;
		ptr->next = start;
		start->prev = ptr;
		start = ptr;
	}
	return start;
}

struct node *insert_end(struct node *start, int value)
{
	struct node *ptr, *p;
	if(start == NULL)
		start = create(value);
	else
	{
		ptr = (struct node *)malloc(sizeof(struct node));
		ptr->prev = NULL;
		ptr->data = value;
		ptr->next = NULL;
		p = start;
		while(p->next!=NULL)
			p=p->next;
		ptr->prev = p;
		p->next = ptr;
	}
	return start;
}

struct node *insert_mid(struct node *start, int value, int position)
{
	struct node *ptr,*p;
	int i;
	if(start == NULL)
		printf("\nLinked list does not exist.");
	else if(position < 1 || position > count_nodes(start))
		printf("\nPosition is not valid.");
	else if(position == 1)
		start = insert_front(start, value);
	else
	{
		ptr = (struct node *)malloc(sizeof(struct node));
		ptr->prev = NULL;
		ptr->data = value;
		ptr->next = NULL;
		
		p = start;
		for(i = 1; i < (position-1); i++)
			p = p->next;
		ptr->prev = p;
		ptr->next = p->next;
		p->next->prev = ptr;
		p->next = ptr;
	}
	return start;
}

struct node *insert_after(struct node *start, int value, int targetValue)
{
	struct node *p, *q, *ptr;
	q = NULL;
	if(start == NULL)
		printf("\nLinked list is empty.");
	else
	{	
		p = start;
		while(p !=NULL)
		{
			if(p->data == targetValue)
			{
				q = p;
				break;
			}
			p = p->next;
		}
		if(q == NULL)
		{
			printf("\nData not Found");
		}
		else if(q->next == NULL)
		{
			start = insert_end(start, value);
		}
		else
		{
			ptr = (struct node *)malloc(sizeof(struct node));
			ptr->data = value;
			ptr->prev = q;
			ptr->next = q->next;
			q->next->prev = ptr;
			q->next = ptr;
		}
	}
	return start;
}

struct node *insert_before(struct node *start, int value, int targetValue)
{
	struct node *p, *q, *ptr;
	q = NULL;
	if(start == NULL)
		printf("\nLinked list is empty.");
	else
	{	
		p = start;
		while(p != NULL)
		{
			if(p->data == targetValue)
			{
				q = p;
				break;
			}
			p = p->next;
		}
		if(q == NULL)
		{
			printf("\nData not Found");
		}
		else if(q->prev == NULL)
		{
			start = insert_front(start, value);
		}
		else
		{
			ptr = (struct node *)malloc(sizeof(struct node));
			ptr->data = value;
			ptr->prev = q->prev;
			ptr->next = q;
			q->prev->next = ptr;
			q->prev = ptr;
		}
	}
	return start;
}


struct node *delete_front(struct node *start)
{
	struct node *p;
	if(start == NULL)
		printf("\nLinked list is empty.");
	else if(start->next==NULL)
	{
		start = NULL;
	}
	else
	{
		p = start;
		start = start->next;
		start->prev = NULL;
		free(p);
	}
	return start;
}

struct node *delete_end(struct node *start)
{
	struct node *p, *ptr;
	if(start == NULL)
		printf("\nLinked list is empty.");
	else if(start->next == NULL)
	{
		p = start;
		start = NULL;
		free(p);
	}
	else
	{
		p = start;
		while(p->next->next != NULL)
		{
			p = p->next;
		}
		ptr = p->next;
		p->next = NULL;
		free(ptr);
	}
	return start;
}

struct node *delete_mid(struct node *start, int position)
{
	struct node *p, *ptr;
	int i;
	
	if(start == NULL)
		printf("\nLinked list does not exist.");
	else if(position < 1 || position > count_nodes(start))
		printf("\nPosition is not valid.");
	else if(position == 1)
		start = delete_front(start);
	else if(position == count_nodes(start))
	{
		p = start;
		for(i = 1; i <= (position-1); i++)
			p = p->next;
		
		ptr = p;
		p->prev->next = p->next;
		free(ptr);
	}
	else
	{
		p = start;
		for(i = 1; i <= (position-1); i++)
			p = p->next;
		
		ptr = p;
		p->next->prev = p->prev;
		p->prev->next = p->next;
		free(ptr);
	}
	return start;
}

struct node *delete_after(struct node *start, int targetValue)
{
	struct node *p, *q, *ptr;
	q = NULL;
	if(start == NULL)
		printf("\nLinked list is empty.");
	else
	{	
		p = start;
		while(p !=NULL)
		{
			if(p->data == targetValue)
			{
				q = p;
				break;
			}
			p = p->next;
		}
		if(q == NULL)
		{
			printf("\nData not Found");
		}
		else if(q->next == NULL)
		{
			printf("\nNo node after %u", targetValue);
		}
		else if(q->next->next == NULL)
		{
			start = delete_end(start);
		}
		else
		{
			q = q->next;
			ptr = q;
			q->next->prev = q->prev;
			q->prev->next = q->next;
			free(ptr);
		}
	}
	return start;
}

struct node *delete_before(struct node *start, int targetValue)
{
	struct node *p, *q, *ptr;
	q = NULL;
	if(start == NULL)
		printf("\nLinked list is empty.");
	else
	{	
		p = start;
		while(p !=NULL)
		{
			if(p->data == targetValue)
			{
				q = p;
				break;
			}
			p = p->next;
		}
		if(q == NULL)
		{
			printf("\nData not Found");
		}
		else if(q->prev == NULL)
		{
			printf("\nNo node before %u", targetValue);
		}
		else if(q->prev->prev == NULL)
		{
			start = delete_front(start);
		}
		else
		{
			q = q->prev;
			ptr = q;
			q->next->prev = q->prev;
			q->prev->next = q->next;
			free(ptr);
		}
	}
	return start;
}

int count_nodes(struct node *start)
{
	struct node *ptr;
	int f = 0;
	ptr = start;
	while(ptr != NULL)
	{
		f++;
		ptr = ptr->next;
	}
	return f;
}

void display(struct node *start)
{
	struct node *p;
	p = start;
	if(start==NULL)
	{
		printf("\nList is Empty.");
	}
	else
	{
		printf("\nThe element(s) are:");
		while(p != NULL)
		{
			printf(" %d",p->data);
			p = p->next;
		}
	}
}

int main()
{
	struct node *start = NULL;
	int num, pos, ch, val, n;
	while(1)
	{
		printf("\nEnter 1 to create list\n2 to display\n3 to insert at begining\n4 to insert at end\n5 to insert at midddle\n6 to insert before\n7 to insert after\n8 to delete from begining\n9 to delete from end\n10 to delete from middle\n11 to delete before\n12 to delete after\n13 to the no. of count nodes\n0 to exit: ");
		scanf("%d",&ch);
		switch(ch){
			case 1:
				printf("\nEnter the data : ");
				scanf("%d",&num);
				start = create(num);
				break;
   			case 2:
				display(start);
				break;
			case 3:
				printf("\nEnter the data : ");
				scanf("%d",&num);
				start = insert_front(start,num);
				break;
			case 4:
				printf("\nEnter the data : ");
				scanf("%d",&num);
				start=insert_end(start,num);
				break;
			case 5:
				printf("\nEnter the data : ");
				scanf("%d",&num);
				printf("\nEnter position :");
				scanf("%d",&pos);
				start=insert_mid(start,num,pos);
				break;
			case 6:
				printf("\nEnter the data : ");
				scanf("%d",&num);
				printf("\nEnter target value :");
				scanf("%d",&val);
				start = insert_before(start,num,val);
				break;
			case 7:
				printf("\nEnter the data : ");
				scanf("%d",&num);
				printf("\nEnter target value :");
				scanf("%d",&val);
				start = insert_after(start,num,val);
				break;
			case 8:
				start = delete_front(start);
				break;
			case 9:
				start = delete_end(start);
				break;
			case 10:
				printf("\nEnter position :");
				scanf("%d",&pos);
				start = delete_mid(start,pos);
				break;
			case 11:
				printf("\nEnter target value :");
				scanf("%d",&val);
				start = delete_before(start,val);
				break;
			case 12:
				printf("\nEnter target value :");
				scanf("%d",&val);
				start = delete_after(start,val);
				break;
			case 13:
				n = count_nodes(start);
				if (n == 0)
 					printf("\nList is Empty");
 				else
 					printf("\nNo. of node(s): %d",n);
				break;
			case 0:
				printf("\nExit Successfully!");
				exit(0);
			default:
				printf("\nWrong Input!");
		}
	}
	return 0;
}
